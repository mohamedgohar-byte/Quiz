import { GoogleGenAI, Type } from '@google/genai';
import { processDocumentForGemini } from './fileUtils';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface GeneratedQuiz {
  title: string;
  questions: GeneratedQuestion[];
}

export interface GeneratedQuestion {
  text: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export async function generateQuizFromDocument(file: File, numQuestions: number = 10, difficulty: string = "medium", language: string = "Arabic"): Promise<GeneratedQuiz> {
  const fileContent = await processDocumentForGemini(file);
  
  const contentParts: any[] = [];
  contentParts.push({ text: `Create a professional, challenging multiple-choice quiz based on the provided document content. 
Generate specifically ${numQuestions} questions.
The difficulty should be ${difficulty}.
The language of the quiz MUST be in ${language}.
Focus on extracting the most important, conceptual, and educational points.
Ensure there are 4 options per question, only 1 correct answer, and an insightful explanation of why the correct answer is right and why distractors are wrong.`});
  
  if (fileContent.text) {
    contentParts.push({ text: fileContent.text });
  } else if (fileContent.inlineData) {
    contentParts.push({ inlineData: fileContent.inlineData });
  }

  // Add images if extracted from PPTX
  if (fileContent.images && fileContent.images.length > 0) {
    fileContent.images.forEach(img => {
      contentParts.push({
        inlineData: {
          mimeType: img.mimeType,
          data: img.data
        }
      });
    });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-pro-preview',
    contents: { parts: contentParts },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: {
            type: Type.STRING,
            description: "A catchy, short title for the quiz based on the text."
          },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING, description: "The quiz question text." },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "4 possible answer options."
                },
                correctAnswerIndex: {
                  type: Type.INTEGER,
                  description: "The 0-based index of the correct option (0, 1, 2, or 3)."
                },
                explanation: {
                  type: Type.STRING,
                  description: "A brief educational explanation of the correct answer."
                }
              },
              required: ["text", "options", "correctAnswerIndex", "explanation"]
            }
          }
        },
        required: ["title", "questions"]
      }
    }
  });

  const rawJson = response.text?.trim();
  if (!rawJson) {
    throw new Error('Failed to generate quiz from Gemini API.');
  }

  return JSON.parse(rawJson) as GeneratedQuiz;
}
