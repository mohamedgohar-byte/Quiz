import JSZip from 'jszip';

export async function extractContentFromPptx(file: File): Promise<{text: string, images: {mimeType: string, data: string}[]}> {
  const zip = new JSZip();
  let extractedText = '';
  const images: {mimeType: string, data: string}[] = [];

  try {
    const loadedZip = await zip.loadAsync(file);
    const slideFiles: string[] = [];

    // Find all slide XML files
    loadedZip.folder('ppt/slides')?.forEach((relativePath) => {
      if (relativePath.match(/slide\d+\.xml/)) {
        slideFiles.push(`ppt/slides/${relativePath}`);
      }
    });

    // Process each slide text
    for (const slidePath of slideFiles) {
      const slideXmlFile = loadedZip.file(slidePath);
      if (slideXmlFile) {
        const xmlContent = await slideXmlFile.async('string');
        const textSnippets = xmlContent.match(/<a:t>([\s\S]*?)<\/a:t>/g) || [];
        
        const slideText = textSnippets
          .map(snippet => snippet.replace(/<a:t>/, '').replace(/<\/a:t>/, ''))
          .filter(text => text.trim().length > 0)
          .join(' ');

        if (slideText) {
          extractedText += slideText + '\n\n';
        }
      }
    }

    // Extract images
    loadedZip.folder('ppt/media')?.forEach((relativePath, file) => {
      if (!file.dir) {
        slideFiles.push(`ppt/media/${relativePath}`);
      }
    });

    const mediaFolder = loadedZip.folder('ppt/media');
    if (mediaFolder) {
      const mediaFiles = Object.keys(mediaFolder.files);
      for (const fileName of mediaFiles) {
        const file = mediaFolder.files[fileName];
        if (!file.dir) {
          const extension = fileName.split('.').pop()?.toLowerCase();
          let mimeType = '';
          if (extension === 'png') mimeType = 'image/png';
          else if (extension === 'jpg' || extension === 'jpeg') mimeType = 'image/jpeg';
          else if (extension === 'gif') mimeType = 'image/gif';
          
          if (mimeType) {
            const base64Data = await file.async('base64');
            images.push({ mimeType, data: base64Data });
          }
        }
      }
    }

    return { text: extractedText.trim(), images };
  } catch (error) {
    console.error('Error extracting content from PPTX:', error);
    throw new Error('Could not parse the PPTX file. Please ensure it is a valid format.');
  }
}

