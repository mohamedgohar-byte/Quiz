import { extractContentFromPptx } from './pptx-extractor';

export async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64String = result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = error => reject(error);
    reader.readAsDataURL(file);
  });
}

export async function processDocumentForGemini(file: File): Promise<{ text?: string; inlineData?: { mimeType: string; data: string }, images?: {mimeType: string, data: string}[] }> {
  // If PPTX, extract text and images to avoid inlineData unsupported issues
  if (file.name.endsWith('.pptx') || file.type === 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
    const { text, images } = await extractContentFromPptx(file);
    return { 
      text: `Extracted Presentation Content:\n\n${text}`,
      images
    };
  }

  // If PDF, use inlineData (Gemini 1.5/2.0/3.0 natively support this)
  if (file.type === 'application/pdf') {
    const base64 = await fileToBase64(file);
    return {
      inlineData: {
        mimeType: 'application/pdf',
        data: base64
      }
    };
  }

  throw new Error('Unsupported file format. Please upload a PDF or PPTX.');
}
