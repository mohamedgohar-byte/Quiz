import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import LandingPage from '@/pages/LandingPage';
import TakeQuizPage from '@/pages/TakeQuizPage';
import MyQuizzesPage from '@/pages/MyQuizzesPage';
import { Sparkles, Compass } from 'lucide-react';
import { ThemeProvider } from '@/components/theme-provider';
import { ThemeToggle } from '@/components/ThemeToggle';

export default function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="quiz-theme">
      <Router>
        <div className="min-h-screen bg-slate-50 dark:bg-[#030014] text-slate-800 dark:text-slate-200 font-sans flex flex-col relative overflow-hidden transition-colors duration-300">
          {/* Ambient Background Effects */}
          <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-purple-500/20 dark:bg-purple-600/20 blur-[100px] md:blur-[150px] rounded-full pointer-events-none z-0"></div>
          <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-cyan-500/20 dark:bg-cyan-600/20 blur-[100px] md:blur-[150px] rounded-full pointer-events-none z-0"></div>

          <nav className="w-full flex items-center justify-between px-6 lg:px-12 py-5 border-b border-slate-200/50 dark:border-white/5 backdrop-blur-2xl bg-white/50 dark:bg-[#030014]/50 sticky top-0 z-50">
            <Link to="/" className="flex items-center gap-3 text-2xl font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-cyan-600 dark:from-purple-400 dark:to-cyan-400 hover:opacity-80 transition-opacity">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.3)] dark:shadow-[0_0_20px_rgba(168,85,247,0.4)]">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span>QuizGenius</span>
            </Link>
            <div className="flex items-center space-x-4 lg:space-x-6 text-sm font-medium">
              <Link to="/" className="hover:text-purple-600 dark:hover:text-cyan-400 transition-colors hidden sm:block">Home</Link>
              <Link to="/my-quizzes" className="hover:text-purple-600 dark:hover:text-cyan-400 transition-colors hidden sm:block">Archive</Link>
              <Link to="/my-quizzes" className="bg-white hover:bg-slate-50 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 px-5 py-2.5 rounded-full text-slate-700 dark:text-white backdrop-blur-md transition-all flex items-center gap-2 shadow-sm hover:shadow-md dark:shadow-none dark:hover:border-cyan-400/50 dark:hover:shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                <Compass className="w-4 h-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </Link>
              <ThemeToggle />
            </div>
          </nav>

          <main className="flex-1 flex flex-col relative z-10 w-full max-w-[1440px] mx-auto min-h-[calc(100vh-160px)]">
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/quiz/:quizId" element={<TakeQuizPage />} />
              <Route path="/my-quizzes" element={<MyQuizzesPage />} />
            </Routes>
          </main>
          
          <footer className="px-6 lg:px-12 py-6 border-t border-slate-200/50 dark:border-white/5 flex justify-between items-center bg-white/50 dark:bg-[#030014]/80 backdrop-blur-lg relative z-10 mt-auto">
            <div className="text-xs text-slate-500 dark:text-slate-500 font-medium tracking-wide">
              &copy; {new Date().getFullYear()} QuizGenius AI.
            </div>
            <div className="flex space-x-2">
              <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></div>
              <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse delay-75"></div>
            </div>
          </footer>
        </div>
        <Toaster position="top-center" richColors />
      </Router>
    </ThemeProvider>
  );
}
