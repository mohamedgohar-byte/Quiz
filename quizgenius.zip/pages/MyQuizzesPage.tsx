import { useEffect, useState } from 'react';
import { db, auth } from '@/firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { Share2, Clock, PlayCircle, FolderArchive, Sparkles, BrainCircuit } from 'lucide-react';
import { toast } from 'sonner';

export default function MyQuizzesPage() {
  const [quizzes, setQuizzes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchQuizzes = async () => {
      if (!auth.currentUser) {
        setLoading(false);
        return;
      }
      
      try {
        const q = query(
          collection(db, 'quizzes'),
          where('creatorId', '==', auth.currentUser.uid),
          orderBy('createdAt', 'desc')
        );
        const querySnapshot = await getDocs(q);
        const fetchedQuizzes = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setQuizzes(fetchedQuizzes);
      } catch (err) {
        console.error("Error fetching quizzes:", err);
      } finally {
        setLoading(false);
      }
    };

    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) fetchQuizzes();
      else setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const shareQuiz = (id: string) => {
    const url = `${window.location.origin}/quiz/${id}`;
    navigator.clipboard.writeText(url);
    toast.success('Link copied to clipboard!');
  };

  if (loading) {
    return (
       <div className="flex-1 flex items-center justify-center min-h-[50vh]">
         <div className="animate-spin rounded-full h-12 w-12 border-4 border-cyan-500 border-t-transparent shadow-[0_0_15px_rgba(6,182,212,0.5)]"></div>
       </div>
    );
  }

  if (!auth.currentUser) {
     return (
       <div className="flex-1 flex flex-col items-center justify-center p-6 text-center min-h-[50vh]">
         <div className="w-20 h-20 bg-slate-100 dark:bg-white/5 rounded-full flex items-center justify-center mb-6 border border-slate-200 dark:border-white/10">
            <FolderArchive className="w-10 h-10 text-slate-400" />
         </div>
         <h2 className="text-3xl font-display font-bold text-slate-800 dark:text-white mb-4">Secure Area</h2>
         <p className="text-slate-600 dark:text-slate-400 mb-8 max-w-md">Please authenticate to access your personal vault of generated quizzes.</p>
         <Link to="/">
           <button className="bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold px-8 py-3 rounded-full shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:scale-105 transition-all">
             Authenticate
           </button>
         </Link>
       </div>
     );
  }

  return (
    <div className="container mx-auto px-6 lg:px-12 py-12 max-w-7xl relative">
      {/* Background flare */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-cyan-600/10 blur-[120px] rounded-full pointer-events-none -z-10"></div>

      <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-50 dark:bg-cyan-500/10 border border-cyan-100 dark:border-cyan-500/20 text-cyan-600 dark:text-cyan-300 text-xs font-semibold uppercase tracking-widest mb-4">
            <FolderArchive className="w-3 h-3" /> Dashboard
          </span>
          <h1 className="text-4xl md:text-5xl font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-500 dark:from-white dark:to-slate-400">
            Your Archives
          </h1>
        </div>
        <Link to="/">
          <button className="bg-white hover:bg-slate-50 dark:bg-white/10 dark:hover:bg-white/20 border border-slate-200 dark:border-white/20 text-slate-700 dark:text-white font-medium px-6 py-2.5 rounded-full transition-all flex items-center gap-2 shadow-sm">
            <Sparkles className="w-4 h-4 text-purple-500 dark:text-purple-400" />
            New Extraction
          </button>
        </Link>
      </div>
      
      {quizzes.length === 0 ? (
        <div className="w-full border-2 border-dashed border-slate-200 dark:border-white/10 rounded-3xl flex flex-col items-center justify-center py-24 text-center bg-white/50 dark:bg-white/5 backdrop-blur-sm relative overflow-hidden">
           <div className="w-16 h-16 bg-white dark:bg-white/5 rounded-full flex items-center justify-center mb-6 shadow-sm">
             <BrainCircuit className="w-8 h-8 text-slate-400 dark:text-slate-500" />
           </div>
           <h3 className="text-2xl font-display font-bold text-slate-800 dark:text-white mb-2">Vault is empty</h3>
           <p className="text-slate-500 dark:text-slate-400 text-sm mb-8">No quizzes have been synthesized yet.</p>
           <Link to="/">
             <button className="bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold px-8 py-3 rounded-full shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:scale-105 transition-all">
               Begin Generation
             </button>
           </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => (
             <div key={quiz.id} className="bg-white/80 dark:bg-[#0f0a1c]/60 backdrop-blur-md border border-slate-200 dark:border-white/10 p-6 rounded-2xl hover:border-cyan-400 dark:hover:border-cyan-500/50 transition-all duration-300 relative group flex flex-col h-full shadow-sm hover:shadow-[0_0_30px_rgba(6,182,212,0.1)]">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl pointer-events-none"></div>
                
                <div className="relative z-10 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center justify-center text-cyan-600 dark:text-cyan-400 font-display font-bold group-hover:bg-cyan-50 dark:group-hover:bg-cyan-500/20 group-hover:border-cyan-200 dark:group-hover:border-cyan-500/40 transition-colors">
                      {quiz.questions.length}
                    </div>
                    <span className="text-[10px] text-slate-500 flex items-center tracking-widest font-medium px-2 py-1 bg-slate-100 dark:bg-black/30 rounded-md">
                      <Clock className="w-3 h-3 mr-1.5" /> 
                      {new Date(quiz.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-display font-bold text-slate-800 dark:text-white mb-8 line-clamp-2 leading-snug group-hover:text-cyan-700 dark:group-hover:text-cyan-100 transition-colors">
                    {quiz.title}
                  </h3>

                  <div className="flex gap-3 mt-auto">
                    <button 
                      className="flex-1 flex justify-center items-center py-2.5 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 rounded-xl text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors shadow-sm dark:shadow-none"
                      onClick={() => shareQuiz(quiz.id)}
                      title="Copy Link"
                    >
                      <Share2 className="w-4 h-4 mr-2" /> Link
                    </button>
                    <button 
                      className="flex-1 flex justify-center items-center py-2.5 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 rounded-xl text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors shadow-sm dark:shadow-none"
                      onClick={() => {
                        const url = `${window.location.origin}/quiz/${quiz.id}`;
                        const subject = encodeURIComponent(`Take this quiz: ${quiz.title}`);
                        const body = encodeURIComponent(`I generated an awesome AI quiz for you to take. Click the link to start:\n\n${url}`);
                        window.location.href = `mailto:?subject=${subject}&body=${body}`;
                      }}
                      title="Share via Email"
                    >
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                      Email
                    </button>
                    <Link to={`/quiz/${quiz.id}`} className="flex-[1.5]">
                      <button className="w-full flex justify-center items-center py-2.5 bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors rounded-xl text-xs font-bold uppercase tracking-wider text-white dark:text-black shadow-md">
                        <PlayCircle className="w-4 h-4 mr-2" /> Play Now
                      </button>
                    </Link>
                  </div>
                </div>
             </div>
          ))}
        </div>
      )}
    </div>
  );
}
