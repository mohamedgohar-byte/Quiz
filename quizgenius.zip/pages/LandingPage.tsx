import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { generateQuizFromDocument } from '@/lib/gemini';
import { db, auth } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { FileUp, Sparkles, Loader2, BrainCircuit, ArrowRight, Settings, Plus, Trash2, CheckSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { nanoid } from 'nanoid';
import confetti from 'canvas-confetti';

export default function LandingPage() {
  const [file, setFile] = useState<File | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusText, setStatusText] = useState('');
  const navigate = useNavigate();

  // Settings
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [timePerQuestion, setTimePerQuestion] = useState<number>(30); // 0 means no limit
  const [showImmediateFeedback, setShowImmediateFeedback] = useState<boolean>(true);
  
  // Edit Mode state
  const [editModeQuiz, setEditModeQuiz] = useState<any>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx']
    },
    maxFiles: 1
  } as any);

  const handleGenerate = async () => {
    if (!file) return;

    if (!auth.currentUser) {
      setStatusText('Please sign in to save your progress.');
      const provider = new GoogleAuthProvider();
      try {
        await signInWithPopup(auth, provider);
      } catch (err) {
        toast.error('Failed to authenticate.');
        return;
      }
    }

    try {
      setIsGenerating(true);
      
      setStatusText('Extracting knowledge...');
      const quizResult = await generateQuizFromDocument(file, 10, difficulty, 'Arabic'); // Forcing Arabic or let user adjust
      
      setStatusText('Assembling the challenge...');
      
      setEditModeQuiz({
        title: quizResult.title,
        questions: quizResult.questions.map((q: any) => ({
          id: nanoid(8),
          ...q
        }))
      });
      
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || 'Failed to generate quiz. Please try again.');
    } finally {
      setIsGenerating(false);
      setStatusText('');
    }
  };

  const handleSaveQuiz = async () => {
    if (!auth.currentUser || !editModeQuiz) return;
    
    if (editModeQuiz.questions.length === 0) {
      toast.error('Please add at least one question to the quiz.');
      return;
    }
    
    // Check if any question is empty
    for (let i = 0; i < editModeQuiz.questions.length; i++) {
        const q = editModeQuiz.questions[i];
        if (!q.text.trim()) {
            toast.error(`Question ${i + 1} text cannot be empty.`);
            return;
        }
        if (q.options.some((opt: string) => !opt.trim())) {
            toast.error(`All options for Question ${i + 1} must be filled.`);
            return;
        }
    }

    try {
      const quizId = nanoid(10);
      await setDoc(doc(db, 'quizzes', quizId), {
        title: editModeQuiz.title,
        creatorId: auth.currentUser.uid,
        questions: editModeQuiz.questions,
        createdAt: new Date().toISOString(),
        settings: {
          difficulty,
          timePerQuestion,
          showImmediateFeedback
        }
      });
      
      confetti({
        particleCount: 150,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#a855f7', '#06b6d4', '#ffffff']
      });
      
      toast.success('Quiz generated and saved successfully!');
      navigate(`/quiz/${quizId}`);
      
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || 'Failed to save quiz.');
    }
  };

  const handleAddQuestion = () => {
    if (!editModeQuiz) return;
    setEditModeQuiz({
      ...editModeQuiz,
      questions: [
        ...editModeQuiz.questions,
        {
          id: nanoid(8),
          text: '',
          options: ['', '', '', ''],
          correctAnswerIndex: 0,
          explanation: ''
        }
      ]
    });
  };

  const handleQuestionChange = (index: number, field: string, value: any) => {
    if (!editModeQuiz) return;
    const newQuestions = [...editModeQuiz.questions];
    newQuestions[index] = { ...newQuestions[index], [field]: value };
    setEditModeQuiz({ ...editModeQuiz, questions: newQuestions });
  };

  const handleOptionChange = (qIndex: number, optIndex: number, value: string) => {
    if (!editModeQuiz) return;
    const newQuestions = [...editModeQuiz.questions];
    newQuestions[qIndex].options[optIndex] = value;
    setEditModeQuiz({ ...editModeQuiz, questions: newQuestions });
  };

  const handleDeleteQuestion = (index: number) => {
    if (!editModeQuiz) return;
    const newQuestions = [...editModeQuiz.questions];
    newQuestions.splice(index, 1);
    setEditModeQuiz({ ...editModeQuiz, questions: newQuestions });
  };

  if (editModeQuiz) {
    return (
      <div className="flex-1 flex flex-col px-6 lg:px-12 py-8 max-w-4xl mx-auto w-full">
        <div className="flex items-center justify-between xl:sticky xl:top-24 bg-slate-50/90 dark:bg-[#030014]/90 backdrop-blur-md p-4 rounded-2xl z-30 mb-8 border border-slate-200 dark:border-white/10 shadow-sm">
          <input
            className="text-2xl font-display font-bold bg-transparent border-none outline-none text-slate-800 dark:text-white w-full max-w-md focus:ring-2 focus:ring-purple-500/50 rounded-lg p-2"
            value={editModeQuiz.title}
            onChange={(e) => setEditModeQuiz({...editModeQuiz, title: e.target.value})}
            placeholder="Quiz Title"
          />
          <button 
            onClick={handleSaveQuiz}
            className="bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold py-2.5 px-6 rounded-xl shadow-[0_0_15px_rgba(168,85,247,0.3)] hover:scale-[1.02] transition-all whitespace-nowrap ml-4 flex items-center gap-2"
          >
            <CheckSquare className="w-5 h-5" /> Save & Publish
          </button>
        </div>

        <div className="space-y-6">
          {editModeQuiz.questions.map((q: any, qIdx: number) => (
            <div key={q.id} className="bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 p-6 rounded-2xl shadow-sm relative">
              <button 
                onClick={() => handleDeleteQuestion(qIdx)}
                className="absolute top-4 right-4 text-red-500 hover:bg-red-500/10 p-2 rounded-lg transition-colors"
                title="Delete Question"
              >
                <Trash2 className="w-5 h-5" />
              </button>
              <div className="mb-4">
                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest block mb-2">Question {qIdx + 1}</label>
                <textarea 
                  value={q.text}
                  onChange={(e) => handleQuestionChange(qIdx, 'text', e.target.value)}
                  className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl p-3 text-slate-800 dark:text-white focus:outline-none focus:border-cyan-500 min-h-[80px]"
                  placeholder="Enter the question text"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                {q.options.map((opt: string, optIdx: number) => (
                  <div key={optIdx} className="flex items-center gap-3">
                    <input 
                      type="radio" 
                      name={`correct-${q.id}`} 
                      checked={q.correctAnswerIndex === optIdx}
                      onChange={() => handleQuestionChange(qIdx, 'correctAnswerIndex', optIdx)}
                      className="w-5 h-5 accent-cyan-500 cursor-pointer"
                    />
                    <input 
                      type="text"
                      value={opt}
                      onChange={(e) => handleOptionChange(qIdx, optIdx, e.target.value)}
                      className={`w-full p-2.5 rounded-lg border focus:outline-none focus:ring-1 bg-slate-50 dark:bg-black/20 text-slate-800 dark:text-white
                        ${q.correctAnswerIndex === optIdx 
                            ? 'border-green-500 focus:border-green-500 focus:ring-green-500 dark:bg-green-500/10' 
                            : 'border-slate-200 dark:border-white/10 focus:border-cyan-500 focus:ring-cyan-500'}`}
                      placeholder={`Option ${optIdx + 1}`}
                    />
                  </div>
                ))}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest block mb-2">Explanation (Optional)</label>
                <textarea 
                  value={q.explanation}
                  onChange={(e) => handleQuestionChange(qIdx, 'explanation', e.target.value)}
                  className="w-full bg-slate-50 dark:bg-black/20 border border-slate-200 dark:border-white/10 rounded-xl p-3 text-slate-800 dark:text-white focus:outline-none focus:border-cyan-500 min-h-[60px]"
                  placeholder="Explain why the answer is correct"
                />
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={handleAddQuestion}
          className="mt-6 w-full py-4 border-2 border-dashed border-slate-300 dark:border-white/20 rounded-2xl flex items-center justify-center gap-2 text-slate-500 dark:text-slate-400 font-bold hover:bg-slate-50 dark:hover:bg-white/5 hover:border-purple-400 transition-all shadow-sm"
        >
          <Plus className="w-5 h-5" /> Add Manual Question
        </button>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col justify-center px-6 lg:px-12 py-12 lg:py-24">
      <div className="w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Left: Copy & Hero */}
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="space-y-8 text-center lg:text-left"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-100 dark:bg-purple-500/10 border border-purple-200 dark:border-purple-500/20 text-purple-600 dark:text-purple-300 text-sm font-semibold shadow-[0_0_15px_rgba(168,85,247,0.15)] backdrop-blur-md">
            <Sparkles className="w-4 h-4 text-cyan-500 dark:text-cyan-400" /> AI-Powered Platform
          </div>
          
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-extrabold leading-[1.1] text-transparent bg-clip-text bg-gradient-to-br from-slate-900 via-slate-700 to-slate-500 dark:from-white dark:via-slate-200 dark:to-slate-500">
            Supercharge <br className="hidden lg:block"/> Your Learning <br className="hidden lg:block"/>
            <span className="bg-clip-text bg-gradient-to-r from-purple-500 to-cyan-500 dark:from-purple-400 dark:to-cyan-400">Instantly.</span>
          </h1>
          
          <p className="text-slate-600 dark:text-slate-400 text-lg sm:text-xl leading-relaxed max-w-lg mx-auto lg:mx-0">
            Upload your PDFs or presentations and let our AI forge highly interactive, visually stunning quizzes in seconds. Both text and images are fully analyzed!
          </p>

          <div className="grid grid-cols-2 gap-6 pt-4 border-t border-slate-200 dark:border-white/5 max-w-lg mx-auto lg:mx-0">
            <div className="glass-panel p-4 rounded-2xl bg-white/50 dark:bg-white/5 border border-slate-200 dark:border-white/10 backdrop-blur-sm shadow-sm md:shadow-none">
              <div className="text-3xl font-display font-bold text-slate-800 dark:text-white mb-1">1.2k+</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-widest">Generations</div>
            </div>
            <div className="glass-panel p-4 rounded-2xl bg-white/50 dark:bg-white/5 border border-slate-200 dark:border-white/10 backdrop-blur-sm shadow-sm md:shadow-none">
              <div className="text-3xl font-display font-bold text-slate-800 dark:text-white mb-1"><BrainCircuit className="w-8 h-8 text-cyan-500 dark:text-cyan-400" /></div>
              <div className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-widest">Powered by Gemini 3.1</div>
            </div>
          </div>
        </motion.div>

        {/* Right: Glassmorphic Hub */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="relative w-full max-w-md mx-auto"
        >
          {/* Animated Glow Behind Card */}
          <div className="absolute inset-0 bg-gradient-to-r from-purple-400/30 to-cyan-400/30 dark:from-purple-600/30 dark:to-cyan-600/30 blur-3xl animate-pulse -z-10 rounded-full"></div>
          
          <div className="bg-white/80 dark:bg-[#0f0a1c]/80 backdrop-blur-2xl border border-slate-200 dark:border-white/10 rounded-3xl p-8 shadow-xl dark:shadow-2xl relative overflow-hidden">
            {/* Glossy top highlight */}
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-slate-300 dark:via-white/30 to-transparent"></div>

            <AnimatePresence mode="wait">
              {!isGenerating ? (
                <motion.div
                  key="upload"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="space-y-6"
                >
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-display font-bold text-slate-800 dark:text-white">Create a Quiz</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">Upload material to get started</p>
                  </div>

                  <div 
                    {...getRootProps()} 
                    className={`w-full aspect-[4/3] border-2 border-dashed rounded-2xl flex flex-col items-center justify-center p-6 transition-all duration-500 cursor-pointer group relative overflow-hidden
                      ${isDragActive ? 'border-cyan-500 bg-cyan-50 dark:bg-cyan-500/10' : 'border-slate-300 dark:border-white/20 bg-slate-50 dark:bg-white/5 hover:border-purple-400 dark:hover:border-purple-500/50 hover:bg-purple-50 dark:hover:bg-purple-500/5'}`}
                  >
                    <input {...getInputProps()} />
                    
                    <div className="w-16 h-16 mb-4 rounded-full bg-white dark:bg-white/5 flex items-center justify-center group-hover:scale-110 group-hover:bg-purple-100 dark:group-hover:bg-purple-500/20 text-slate-400 dark:text-slate-300 transition-all duration-300 border border-slate-200 dark:border-white/10 shadow-sm">
                      <FileUp className="w-8 h-8 text-slate-400 dark:text-slate-300 group-hover:text-purple-500 dark:group-hover:text-purple-400" />
                    </div>
                    
                    <h3 className="text-slate-700 dark:text-white font-medium text-base text-center break-all px-4">
                      {file ? file.name : "Drag & drop your file"}
                    </h3>
                    <p className="text-slate-500 text-xs mt-2 font-medium">
                      {file ? "File ready" : "Supports PDF & PPTX (Max 25MB)"}
                    </p>
                  </div>

                  {/* Settings Panel */}
                  <div className="space-y-4 p-4 bg-slate-50 dark:bg-black/20 rounded-xl border border-slate-200 dark:border-white/5">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-white/10">
                      <label className="text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                        <Settings className="w-4 h-4" /> Difficulty
                      </label>
                      <select 
                        value={difficulty} 
                        onChange={(e) => setDifficulty(e.target.value as any)}
                        className="bg-white dark:bg-white/10 border border-slate-200 dark:border-white/20 text-slate-700 dark:text-white rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-cyan-500"
                      >
                        <option value="easy">Easy</option>
                        <option value="medium">Medium</option>
                        <option value="hard">Hard</option>
                      </select>
                    </div>
                    <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-white/10">
                      <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">Time per Question</label>
                      <select 
                        value={timePerQuestion} 
                        onChange={(e) => setTimePerQuestion(Number(e.target.value))}
                        className="bg-white dark:bg-white/10 border border-slate-200 dark:border-white/20 text-slate-700 dark:text-white rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-cyan-500"
                      >
                        <option value={15}>15s</option>
                        <option value={30}>30s</option>
                        <option value={60}>60s</option>
                        <option value={0}>No Limit</option>
                      </select>
                    </div>
                    <div className="flex items-center justify-between">
                       <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">Immediate Feedback</label>
                       <label className="relative inline-flex items-center cursor-pointer">
                         <input type="checkbox" checked={showImmediateFeedback} onChange={(e) => setShowImmediateFeedback(e.target.checked)} className="sr-only peer" />
                         <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                       </label>
                    </div>
                  </div>

                  {file ? (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                      <button 
                        onClick={handleGenerate}
                        className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold py-4 rounded-xl shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center space-x-2"
                      >
                        <Sparkles className="w-5 h-5" />
                        <span>Generate & Edit Quiz</span>
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </button>
                    </motion.div>
                  ) : (
                    <button 
                      onClick={() => {
                        setEditModeQuiz({
                           title: 'My Custom Quiz',
                           questions: []
                        });
                      }}
                      className="w-full bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-white font-medium py-3 rounded-xl transition-all flex items-center justify-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      Create Manual Quiz
                    </button>
                  )}
                </motion.div>
              ) : (
                <motion.div
                  key="generating"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center py-16 text-center"
                >
                  <div className="relative w-24 h-24 mb-8">
                    <div className="absolute inset-0 border-2 border-slate-200 dark:border-white/10 rounded-full"></div>
                    <div className="absolute inset-0 border-2 border-purple-500 rounded-full border-t-transparent animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center bg-purple-50 dark:bg-purple-500/10 rounded-full blur-md"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <BrainCircuit className="w-10 h-10 text-cyan-500 dark:text-cyan-400 animate-pulse" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-display font-bold text-slate-800 dark:text-white mb-2">Synthesizing...</h3>
                  <p className="text-purple-600 dark:text-purple-300 text-sm font-medium animate-pulse">{statusText}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
