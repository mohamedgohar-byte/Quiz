import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { db } from '@/firebase';
import { doc, getDoc, collection, addDoc } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { Check, X, Trophy, Share2, Play, CircleDot, ArrowRight, Timer, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';

interface Quiz {
  id: string;
  title: string;
  creatorId: string;
  questions: any[];
  settings?: {
    difficulty: string;
    timePerQuestion: number;
    showImmediateFeedback: boolean;
  };
}

export default function TakeQuizPage() {
  const { quizId } = useParams();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [step, setStep] = useState<'intro' | 'playing' | 'results'>('intro');
  const [takerName, setTakerName] = useState('');
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerRevealed, setIsAnswerRevealed] = useState(false);

  const questionTime = quiz?.settings?.timePerQuestion !== undefined ? quiz.settings.timePerQuestion : 30;
  const showImmediateFeedback = quiz?.settings?.showImmediateFeedback !== false; // defaults to true
  const [timeLeft, setTimeLeft] = useState(30);

  useEffect(() => {
    if (quiz) {
      setTimeLeft(questionTime);
    }
  }, [quiz, questionTime]);

  useEffect(() => {
    if (step === 'playing' && !isAnswerRevealed && timeLeft > 0 && questionTime > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (step === 'playing' && !isAnswerRevealed && timeLeft === 0 && questionTime > 0) {
      handleTimeUp();
    }
  }, [step, isAnswerRevealed, timeLeft, questionTime]);

  const handleTimeUp = () => {
    setIsAnswerRevealed(true);
    setSelectedOption(null);
    toast.error("Time's up!");
  };

  useEffect(() => {
    const fetchQuiz = async () => {
      try {
        const docRef = doc(db, 'quizzes', quizId!);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setQuiz({ id: docSnap.id, ...docSnap.data() } as Quiz);
        } else {
          setError('Quiz not found.');
        }
      } catch (err: any) {
        setError('Error accessing quiz.');
        toast.error(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchQuiz();
  }, [quizId]);

  const handleStart = () => {
    if (!takerName.trim()) {
      toast.error('Please enter your name to track your score.');
      return;
    }
    setStep('playing');
  };

  const handleOptionSelect = (idx: number) => {
    if (isAnswerRevealed || (!showImmediateFeedback && selectedOption !== null)) return;
    
    setSelectedOption(idx);
    
    const isCorrect = idx === quiz!.questions[currentQuestionIdx].correctAnswerIndex;
    if (isCorrect) {
      setScore(s => s + 1);
    }
    
    if (showImmediateFeedback) {
      setIsAnswerRevealed(true);
      if (isCorrect) {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
          colors: ['#22c55e', '#ffffff']
        });
      }
    }
  };

  const handleNext = async () => {
    if (currentQuestionIdx < quiz!.questions.length - 1) {
      setCurrentQuestionIdx(idx => idx + 1);
      setSelectedOption(null);
      setIsAnswerRevealed(false);
      setTimeLeft(questionTime);
    } else {
      try {
        const finalScore = score;
        await addDoc(collection(db, 'quizzes', quizId!, 'attempts'), {
          quizId: quizId!,
          takerName: takerName.trim(),
          score: finalScore,
          total: quiz!.questions.length,
          completedAt: new Date().toISOString()
        });
      } catch (err) {
         console.error('Failed to log attempt', err);
      }
      
      confetti({
        particleCount: 200,
        spread: 160,
        origin: { y: 0.4 },
        colors: ['#a855f7', '#06b6d4', '#ec4899', '#ffffff']
      });
      setStep('results');
    }
  };

  const shareQuiz = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Quiz link copied to clipboard!');
  };

  if (loading) return (
    <div className="flex-1 flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent shadow-[0_0_15px_rgba(168,85,247,0.5)]"></div>
    </div>
  );

  if (error || !quiz) return (
    <div className="flex-1 flex items-center justify-center text-red-400 font-medium bg-red-500/10 backdrop-blur-md px-8 py-4 rounded-2xl border border-red-500/20 max-w-md mx-auto mt-20">
      {error}
    </div>
  );

  const currentQ = quiz.questions[currentQuestionIdx];
  const canGoNext = isAnswerRevealed || (!showImmediateFeedback && selectedOption !== null);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 lg:p-8 w-full max-w-4xl mx-auto">
      <AnimatePresence mode="wait">
        
        {step === 'intro' && (
          <motion.div 
            key="intro"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="w-full max-w-lg relative"
          >
            {/* Glow under card */}
            <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-cyan-400 dark:from-purple-500 dark:to-cyan-500 blur-2xl opacity-20 -z-10 rounded-full"></div>
            
            <div className="bg-white/90 dark:bg-[#0f0a1c]/90 backdrop-blur-xl border border-slate-200 dark:border-white/10 rounded-3xl p-8 lg:p-12 text-center shadow-2xl">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-[0_0_15px_rgba(6,182,212,0.3)] dark:shadow-[0_0_20px_rgba(6,182,212,0.4)]">
                <CircleDot className="w-8 h-8 text-white" />
              </div>

              <span className="inline-block px-3 py-1 rounded-full bg-cyan-50 dark:bg-white/5 border border-cyan-100 dark:border-white/10 text-cyan-600 dark:text-cyan-300 text-xs font-semibold tracking-wider mb-6">
                Interactive Assessment
              </span>

              <h1 className="text-3xl lg:text-4xl font-display font-bold text-slate-800 dark:text-white mb-4 leading-tight">{quiz.title}</h1>
              
              <div className="flex items-center justify-center gap-2 text-slate-500 dark:text-slate-400 text-sm font-medium mb-10">
                <span>{quiz.questions.length} Questions</span>
                <span className="w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-600"></span>
                <span>Powered by AI</span>
              </div>
              
              <div className="space-y-6 text-left">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest pl-2">Display Name</label>
                  <input 
                    type="text"
                    placeholder="e.g. Alex" 
                    value={takerName}
                    onChange={(e) => setTakerName(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-xl px-5 py-4 text-slate-800 dark:text-white outline-none transition-all placeholder:text-slate-400 dark:placeholder:text-white/20 font-medium shadow-inner dark:shadow-none"
                    onKeyDown={(e) => e.key === 'Enter' && handleStart()}
                  />
                </div>
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <button onClick={shareQuiz} className="flex-1 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 border border-slate-200 dark:border-white/20 text-slate-700 dark:text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2">
                    <Share2 className="w-5 h-5" />
                    <span>Copy Link</span>
                  </button>
                  <button onClick={() => {
                    const subject = encodeURIComponent(`Take this quiz: ${quiz.title}`);
                    const body = encodeURIComponent(`I generated an awesome AI quiz for you to take. Click the link to start:\n\n${window.location.href}`);
                    window.location.href = `mailto:?subject=${subject}&body=${body}`;
                  }} className="flex-1 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 border border-slate-200 dark:border-white/20 text-slate-700 dark:text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    <span>Email</span>
                  </button>
                </div>
                <button onClick={handleStart} className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold py-4 rounded-xl shadow-[0_0_15px_rgba(168,85,247,0.3)] dark:shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] dark:hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] hover:scale-[1.02] transition-all flex items-center justify-center gap-2">
                  <span>Start Quiz</span>
                  <Play className="w-5 h-5 fill-current" />
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {step === 'playing' && (
          <motion.div 
            key="playing"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="w-full relative"
          >
            {/* Ambient glows */}
            <div className="absolute top-[-50px] left-[-50px] w-40 h-40 bg-purple-600/30 blur-[80px] rounded-full pointer-events-none -z-10"></div>

            <div className="mb-8 p-1">
              <div className="flex justify-between items-center mb-4">
                <div className="space-y-1">
                  <div className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">
                    Question <span className="text-slate-800 dark:text-white text-lg">{currentQuestionIdx + 1}</span> / {quiz.questions.length}
                  </div>
                  <div className="w-32 h-1 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
                     <motion.div 
                       className="h-full bg-slate-600 dark:bg-slate-500 rounded-full"
                       initial={{ width: `${((currentQuestionIdx) / quiz.questions.length) * 100}%` }}
                       animate={{ width: `${((currentQuestionIdx + 1) / quiz.questions.length) * 100}%` }}
                       transition={{ duration: 0.5, ease: "easeInOut" }}
                     />
                  </div>
                </div>
                
                <div className={`flex items-center gap-2 px-5 py-2 rounded-2xl border ${timeLeft <= 5 ? 'bg-red-50 dark:bg-red-500/20 border-red-200 dark:border-red-500/50 text-red-500 dark:text-red-400 shadow-[0_0_20px_rgba(239,68,68,0.2)] animate-pulse' : 'bg-white/50 dark:bg-white/5 border-slate-200 dark:border-white/10 text-cyan-600 dark:text-cyan-400 shadow-sm dark:shadow-md'} transition-all`}>
                   <Timer className="w-5 h-5" />
                   <span className="font-display font-bold text-2xl tabular-nums">{timeLeft}s</span>
                </div>
              </div>
            </div>

            <div className="w-full bg-white/90 dark:bg-[#0f0a1c]/80 backdrop-blur-xl border border-slate-200 dark:border-white/10 rounded-3xl p-6 lg:p-12 shadow-xl dark:shadow-2xl">
              <h2 className="text-2xl lg:text-3xl font-display font-semibold text-slate-800 dark:text-white mb-10 leading-snug">
                {currentQ.text}
              </h2>

              <div className="space-y-4">
                {currentQ.options.map((opt: string, idx: number) => {
                  const isSelected = selectedOption === idx;
                  const isCorrectAnswer = idx === currentQ.correctAnswerIndex;
                  const showCorrect = isAnswerRevealed && isCorrectAnswer;
                  const showIncorrect = isAnswerRevealed && isSelected && !isCorrectAnswer;
                  
                  let optionClass = "border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 hover:border-purple-300 dark:hover:border-purple-500/50 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 shadow-sm";
                  let icon = <div className="w-6 h-6 rounded-full border border-slate-300 dark:border-white/20 flex-shrink-0 ml-4 group-hover:border-purple-400 transition-colors"></div>;

                  if (showCorrect) {
                     optionClass = "border-green-400 dark:border-green-500 bg-green-50 dark:bg-green-500/10 text-green-700 dark:text-white shadow-[0_0_20px_rgba(34,197,94,0.15)]";
                     icon = <Check className="w-6 h-6 text-green-500 dark:text-green-400 ml-4 flex-shrink-0" />;
                  } else if (showIncorrect) {
                     optionClass = "border-red-300 dark:border-red-500/50 bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-slate-300";
                     icon = <X className="w-6 h-6 text-red-500 dark:text-red-400 ml-4 flex-shrink-0" />;
                  } else if (isAnswerRevealed) {
                     optionClass = "border-slate-100 dark:border-white/5 bg-transparent text-slate-400 dark:text-slate-500 opacity-50";
                  } else if (!showImmediateFeedback && isSelected) {
                     optionClass = "border-cyan-400 dark:border-cyan-500 bg-cyan-50 dark:bg-cyan-500/10 text-cyan-700 dark:text-white shadow-[0_0_20px_rgba(6,182,212,0.15)]";
                     icon = <div className="w-6 h-6 rounded-full bg-cyan-500 border-none flex-shrink-0 ml-4"></div>;
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleOptionSelect(idx)}
                      disabled={isAnswerRevealed || (!showImmediateFeedback && selectedOption !== null)}
                      className={`w-full text-left p-5 transition-all duration-300 font-medium text-lg rounded-2xl flex items-center justify-between group ${optionClass}`}
                    >
                      <span className="flex-1">{opt}</span>
                      {icon}
                    </button>
                  );
                })}
              </div>

              {isAnswerRevealed && (
                <motion.div 
                  initial={{ opacity: 0, height: 0, y: 10 }}
                  animate={{ opacity: 1, height: 'auto', y: 0 }}
                  className="mt-8 pt-8 border-t border-slate-200 dark:border-white/10"
                >
                  <div className="bg-gradient-to-r from-purple-50 dark:from-purple-500/10 to-transparent border-l-4 border-purple-400 p-6 rounded-tr-2xl rounded-br-2xl mb-8">
                    <h4 className="font-display font-bold text-purple-700 dark:text-purple-300 mb-2 flex items-center gap-2">
                      <Sparkles className="w-4 h-4" /> Why is this correct?
                    </h4>
                    <p className="text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                      {currentQ.explanation}
                    </p>
                  </div>
                </motion.div>
              )}

              {canGoNext && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-6 flex justify-end"
                >
                  <button onClick={handleNext} className="w-full sm:w-auto flex items-center justify-center gap-2 bg-slate-900 dark:bg-white text-white dark:text-black font-bold px-8 py-4 rounded-xl hover:bg-slate-800 dark:hover:bg-slate-200 shadow-md transition-all active:scale-[0.98]">
                    <span>{currentQuestionIdx < quiz.questions.length - 1 ? 'Next Question' : 'View Results'}</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}

        {step === 'results' && (
          <motion.div 
            key="results"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-xl text-center relative"
          >
             <div className="absolute inset-0 bg-gradient-to-b from-cyan-400/20 to-purple-400/20 dark:from-cyan-500/20 dark:to-purple-500/20 blur-3xl -z-10 rounded-full"></div>
             
             <div className="bg-white/90 dark:bg-[#0f0a1c]/90 backdrop-blur-xl border border-slate-200 dark:border-white/10 p-10 lg:p-16 rounded-3xl shadow-xl dark:shadow-2xl">
                <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-[0_0_30px_rgba(250,204,21,0.3)]">
                  <Trophy className="w-12 h-12 text-white" />
                </div>
                
                <h2 className="text-5xl lg:text-6xl font-display font-bold text-slate-800 dark:text-white mb-4">
                  {score}<span className="text-slate-400 dark:text-slate-500 text-3xl mx-2">/</span>{quiz.questions.length}
                </h2>
                
                <p className="text-lg text-purple-600 dark:text-purple-300 font-medium mb-12">
                  Spectacular effort, {takerName}!
                </p>
                
                <div className="grid grid-cols-2 gap-4 mb-10">
                  <div className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 p-6 rounded-2xl">
                     <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2">Accuracy</p>
                     <p className="text-4xl font-display font-bold text-cyan-600 dark:text-cyan-400">{Math.round((score / quiz.questions.length) * 100)}%</p>
                  </div>
                  <div className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 p-6 rounded-2xl">
                     <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-2">Questions</p>
                     <p className="text-4xl font-display font-bold text-slate-800 dark:text-white">{quiz.questions.length}</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button onClick={shareQuiz} className="flex-1 flex items-center justify-center gap-2 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 border border-slate-200 dark:border-white/20 py-4 rounded-xl text-slate-700 dark:text-white font-bold transition-all hover:border-cyan-400/50 hover:shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                    <Share2 className="w-5 h-5" /> 
                    <span>Copy Link</span>
                  </button>
                  <button onClick={() => {
                    const subject = encodeURIComponent(`I scored ${score}/${quiz.questions.length} on ${quiz.title}!`);
                    const body = encodeURIComponent(`Can you beat my score? Take the quiz here:\n\n${window.location.href}`);
                    window.location.href = `mailto:?subject=${subject}&body=${body}`;
                  }} className="flex-1 flex items-center justify-center gap-2 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 border border-slate-200 dark:border-white/20 py-4 rounded-xl text-slate-700 dark:text-white font-bold transition-all hover:border-purple-400/50 hover:shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    <span>Email Result</span>
                  </button>
                </div>
             </div>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
